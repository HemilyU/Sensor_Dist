package org.example;

import javax.swing.*;

import javax.swing.JFrame;

public class LogApp extends JFrame{
    private JPanel jPanelMain;
    private JTextArea logMsg;
    private JLabel logLabel;
    private JButton btnClear;
    private JButton btnLog;

    HandleMsg msg;

    public LogApp(String title){
        super(title);
        this.setContentPane(jPanelMain);
        this.pack();
        logLabel.setText("Log Label");
        logMsg.setText("Logs:");
        btnLog.setText("Download");
    }

    public void writeMsg(String msg){
        logMsg.append("/n "+ msg);

    }
}
