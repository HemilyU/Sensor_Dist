package org.example;

import com.microsoft.azure.sdk.iot.device.*;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;
import com.microsoft.azure.sdk.iot.service.messaging.IotHubServiceClientProtocol;

import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class HandleMsg {

    public static void main(String[] args) throws IotHubClientException {
        String moduleConnectionString="HostName=IotHubTiago.azure-devices.net;DeviceId=Device2072622;ModuleId=TelemetryReader;SharedAccessKey=Awo9ZDh6gBOr1m1kKz2IRveBRcK6isy0wAIoTEYNU9Y=";
        IotHubClientProtocol protocol= IotHubClientProtocol.AMQPS;

        ModuleClient client = new ModuleClient(moduleConnectionString, protocol);

        System.out.println("Successfully created an IoT Hub client.");

        client.setConnectionStatusChangeCallback(new IotHubConnectionStatusChangeCallbackLogger(),null);

        client.setMessageCallback(new MessageCallback() {
            @Override
            public IotHubMessageResult onCloudToDeviceMessageReceived(Message message, Object o) {
                System.out.println("Received message: "+new String(message.getBytes(), Message.DEFAULT_IOTHUB_MESSAGE_CHARSET));
                System.out.println("Message content: "+message.getMessageId());
                return IotHubMessageResult.COMPLETE;
            }
        }, null);

        System.out.println("Successfully set message callback.");


        client.open(true);

        System.out.println("Opened connection to IoT Hub. Messages sent to this device will now be received.");

        System.out.println("Press any key to exit...");

        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8.name());
        scanner.nextLine();
        System.out.println("Shutting down...");
        client.close();
    }
}
