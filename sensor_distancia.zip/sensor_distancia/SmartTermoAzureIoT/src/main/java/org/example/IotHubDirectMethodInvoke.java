package org.example;

import com.microsoft.azure.sdk.iot.service.exceptions.IotHubException;
import com.microsoft.azure.sdk.iot.service.methods.DirectMethodRequestOptions;
import com.microsoft.azure.sdk.iot.service.methods.DirectMethodResponse;
import com.microsoft.azure.sdk.iot.service.methods.DirectMethodsClient;

import java.io.IOException;



public class IotHubDirectMethodInvoke {
    public static void invoke(String methodName, DirectMethodRequestOptions options) throws IOException, IotHubException {
        DirectMethodsClient client= new DirectMethodsClient("HostName=IotHubTiago.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=Nq14Ik6v1FhFHmhl7D66DT8x67BAhaTkZAIoTI0zXUw=");



        DirectMethodResponse response = client.invoke("Device2072622","TelemetryReader", methodName, options);

    }
}
