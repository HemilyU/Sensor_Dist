package org.example;

import com.microsoft.azure.sdk.iot.device.IotHubClientProtocol;
import com.microsoft.azure.sdk.iot.device.ModuleClient;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;
import com.microsoft.azure.sdk.iot.device.twin.DirectMethodPayload;
import com.microsoft.azure.sdk.iot.device.twin.DirectMethodResponse;
import com.microsoft.azure.sdk.iot.device.twin.MethodCallback;

public class IotHubDirectMethodSubscribe {

    public static void main(String[] args) throws IotHubClientException, InterruptedException {

        String moduleConnectionString="HostName=IotHubTiago.azure-devices.net;DeviceId=Device2072622;ModuleId=TelemetryReader;SharedAccessKey=Awo9ZDh6gBOr1m1kKz2IRveBRcK6isy0wAIoTEYNU9Y=";
        IotHubClientProtocol protocol= IotHubClientProtocol.AMQPS;

        ModuleClient client = new ModuleClient(moduleConnectionString, protocol);

        client.setConnectionStatusChangeCallback(new IotHubConnectionStatusChangeCallbackLogger(), null);

        client.open(true);

        try {
            System.out.println("Opened connection to IoT Hub.");
            client.subscribeToMethods(new MethodCallback() {
                @Override
                public DirectMethodResponse onMethodInvoked(String methodName, DirectMethodPayload methodData, Object o) {
                    int status= 200;
                    System.out.println("Received a direct method invocation with name " + methodName + " and payload " + methodData.getPayloadAsJsonString());

                    if (methodName.equals("alarmeStatus")) {
                        IotHubDirectMethodSubscribe.alarmeFunction(methodData);
                    }else if (methodName.equals("dist_min")){
                        IotHubDirectMethodSubscribe.distFunction(methodData);
                    }else {
                        status= 404;
                    }
                    return new DirectMethodResponse(status, methodData);
                }
            },null);
        }catch (IotHubClientException e)
            {
                System.out.println("Failed to subscribe to direct methods. Error code: " + e.getStatusCode());
                client.close();
                System.out.println("Shutting down...");
                return;
            }


    }

    public static void alarmeFunction(DirectMethodPayload payload){
        System.out.println("Message of string: "+payload.getPayloadAsJsonString());

    }
    public static void distFunction(DirectMethodPayload payload){
        System.out.println("Message of string: "+payload.getPayloadAsJsonString());

    }
}
