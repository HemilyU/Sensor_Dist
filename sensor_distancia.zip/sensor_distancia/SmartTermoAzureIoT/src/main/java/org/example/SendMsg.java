package org.example;


import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;
import com.microsoft.azure.sdk.iot.service.exceptions.IotHubException;
import com.microsoft.azure.sdk.iot.service.messaging.IotHubServiceClientProtocol;
import com.microsoft.azure.sdk.iot.service.messaging.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.concurrent.TimeoutException;

public class SendMsg {


    public static void main(String[] args) throws IotHubClientException, InterruptedException {
        SendMsg ss = new SendMsg();
        Random ran = new Random();
        ss.sendMessage(ran.nextInt(300), ran.nextBoolean(), ran.nextBoolean());
    }


    public void sendMessage( double distance, boolean alarm, boolean alert)throws InterruptedException, IotHubClientException {
        String IoTDeviceId="Device2072622";
        String IotModuleId="TelemetryReader";

        String connectionString="HostName=IotHubTiago.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=Nq14Ik6v1FhFHmhl7D66DT8x67BAhaTkZAIoTI0zXUw=";

        IotHubServiceClientProtocol protocol= IotHubServiceClientProtocol.AMQPS;

        MessagingClient client = new MessagingClient(connectionString, protocol);

        int numRequests=1;

        System.out.println("Successfully created an IoT Hub client.");

        try {
            client.open();
        } catch (IotHubException | IOException | TimeoutException e) {
            throw new RuntimeException(e);
        }

        System.out.println("Opened connection to IoT Hub.");
        System.out.println("Sending the following event messages:");

        for (int i = 0; i < numRequests; ++i)
        {
            LocalDateTime timeNow = LocalDateTime.now();


            String msgStr = "{\"Distancia:\":"+ distance + ",Alarme: " + alarm + ",Alerta: "+ alert+" ," + timeNow + "}";

            Message msg = new Message(msgStr);
            msg.setMessageId(java.util.UUID.randomUUID().toString());
            System.out.println(msgStr);

            try
            {
                client.send(IoTDeviceId, IotModuleId, msg);
                System.out.println("Successfully sent the message");
            }
            catch (IotHubException | TimeoutException e)
            {
                System.out.println("Failed to send the message. Status code: " + e.toString());
            }
        }

        // close the connection
        System.out.println("Closing the client...");
        client.close();
    }
}

