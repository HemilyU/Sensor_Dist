package org.example;

import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;
import com.microsoft.azure.sdk.iot.service.exceptions.IotHubException;
import com.microsoft.azure.sdk.iot.service.methods.DirectMethodRequestOptions;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import static org.example.IotHubDirectMethodInvoke.invoke;

public class SmartTermo extends JFrame {
    private JLabel distanciaLabel;
    private JPanel jPanelMain;
    private JLabel logLabel;
    private JLabel statusLabel;
    private JButton toggleStatus;
    private JTextArea logTextArea;
    private JButton dist_minBtn;
    private JSlider distancia_min;
    private boolean status = false;
    private IotHubDirectMethodInvoke invoke;

    private double dist_min;


    private SendMsg msg;

    public SmartTermo(String title) {
        // Configurações da janela principal
        super(title);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setContentPane(jPanelMain);
        this.pack();




        distanciaLabel.setText("Distancia: ");

        logLabel.setText("Log Events");
        logTextArea.setEditable(false);

        statusLabel.setText("Estado do Status: "+ String.valueOf(status));
        toggleStatus.setText(String.valueOf(status));

        dist_minBtn.setText("Alterar Distancia");

        registrarLog("Aplicação iniciada.");


        dist_minBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    sendDistMin();
                } catch (IOException | IotHubException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        toggleStatus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    toggleBtnStatus();
                } catch (IOException | IotHubException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

    }

    private void toggleBtnStatus() throws IOException, IotHubException {

        status= !status;

        registrarLog("Estado Alarme: "+ status);

        toggleStatus.setText(String.valueOf(status));
        statusLabel.setText("Estado do Alarme: "+ String.valueOf(status));


        DirectMethodRequestOptions options=
                DirectMethodRequestOptions.builder()
                        .payload(status)
                        .methodResponseTimeoutSeconds(5)
                        .methodConnectTimeoutSeconds(5)
                        .build();


        invoke("alarmeStatus", options);
    }

    private void sendDistMin() throws IOException, IotHubException {

        dist_min = distancia_min.getValue();

        registrarLog("Distancia min: "+dist_min);



        DirectMethodRequestOptions options=
                DirectMethodRequestOptions.builder()
                        .payload(dist_min)
                        .methodResponseTimeoutSeconds(5)
                        .methodConnectTimeoutSeconds(5)
                        .build();


        invoke("dist_min", options);
    }


    private void registrarLog(String mensagem) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String dataHoraAtual = dateFormat.format(new Date());
        logTextArea.append(dataHoraAtual + " - " + mensagem + "\n");
    }


}

