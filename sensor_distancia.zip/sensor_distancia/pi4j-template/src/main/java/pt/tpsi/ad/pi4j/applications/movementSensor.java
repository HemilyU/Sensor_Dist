package pt.tpsi.ad.pi4j.applications;


import com.pi4j.Pi4J;
import com.pi4j.io.gpio.digital.DigitalInput;
import com.pi4j.io.gpio.digital.DigitalOutput;
import com.pi4j.io.gpio.digital.DigitalState;
import com.pi4j.io.gpio.digital.PullResistance;

import com.pi4j.library.pigpio.PiGpio;
import com.pi4j.plugin.pigpio.provider.gpio.digital.PiGpioDigitalInputProvider;
import com.pi4j.plugin.pigpio.provider.gpio.digital.PiGpioDigitalOutputProvider;
import com.pi4j.plugin.pigpio.provider.i2c.PiGpioI2CProvider;
import com.pi4j.plugin.pigpio.provider.pwm.PiGpioPwmProvider;
import com.pi4j.plugin.pigpio.provider.serial.PiGpioSerialProvider;
import com.pi4j.plugin.pigpio.provider.spi.PiGpioSpiProvider;
import com.pi4j.plugin.raspberrypi.platform.RaspberryPiPlatform;
import pt.tpsi.ad.pi4j.components.UltrasonicDistanceSensorComponent;

import java.time.LocalDateTime;

import pt.tpsi.ad.pi4j.exceptions.MeasurementException;


import static java.lang.Thread.sleep;


public class movementSensor extends RaspberryPiPlatform {


    private static final int PIN_BUTTON = 24; // PIN 18 = BCM 24
    private static final int PIN_LED = 22; // PIN 15 = BCM 22

    public static void main(String[] args) {
        boolean status= true;
        double min_dist= 30.50;
        final boolean[] alarmeWrapper = {false};


        boolean alert;

        final var piGpio = PiGpio.newNativeInstance();
        var pi4j = Pi4J.newContextBuilder()
                .noAutoDetect()
                .add(new movementSensor())
                .add(
                        PiGpioDigitalInputProvider.newInstance(piGpio),
                        PiGpioDigitalOutputProvider.newInstance(piGpio),
                        PiGpioPwmProvider.newInstance(piGpio),
                        PiGpioI2CProvider.newInstance(piGpio),
                        PiGpioSerialProvider.newInstance(piGpio),
                        PiGpioSpiProvider.newInstance(piGpio)
                )
                .build();

        System.out.println("CREATED PI4J Context");

        var ledConfig = DigitalOutput.newConfigBuilder(pi4j)
                .id("led")
                .name("LED Flasher")
                .address(PIN_LED)
                .shutdown(DigitalState.LOW)
                .initial(DigitalState.LOW)
                .provider("pigpio-digital-output");
        var led = pi4j.create(ledConfig);

        var buttonConfig = DigitalInput.newConfigBuilder(pi4j)
                .id("button")
                .name("Press button")
                .address(PIN_BUTTON)
                .pull(PullResistance.PULL_DOWN)
                .debounce(3000L)
                .provider("pigpio-digital-input");
        var button = pi4j.create(buttonConfig);

        final var distanceSensor = new UltrasonicDistanceSensorComponent(pi4j);

        System.out.println("Searching for an object now...");
        distanceSensor.setDetectionRange(5,50);
        distanceSensor.setMeasurementTemperature(23);
        distanceSensor.onObjectFound(() -> System.out.println("Sensor has found a Object in Range!"));
        distanceSensor.onObjectDisappeared(() -> System.out.println("Found Object disappeared!"));
        //sleep(10000);

        System.out.println("Searching completed.");
        distanceSensor.onObjectFound(null);
        distanceSensor.onObjectDisappeared(null);


        button.addListener(e -> {
            if (e.state() == DigitalState.LOW) {
                alarmeWrapper[0] = !alarmeWrapper[0];
            }
        });



        while (status) {
            // Measures the current distance without temperature compensation and prints it to the user.
            try {
                if (alarmeWrapper[0]) {
                    alert = distanceSensor.measure() <= min_dist;
                    if (alert)
                        led.high();
                    else
                        led.low();
                }else {
                    alert = false;
                    led.low();
                }

                LocalDateTime timeNow = LocalDateTime.now();

                System.out.println("{\"Distancia:\":"+ distanceSensor.measure() + "cm ,Alarme: " + alarmeWrapper[0] + ",Alerta: "+ alert+" ," + timeNow + "}");

            }catch (MeasurementException e) {
                // If the measurement fails with a MeasurementException, we inform the user and try again next time
                System.out.println("Oh no. Measurement failed... lets try again");

            }
            // Delay the measurements a little. This gives you some time to move in front of the sensor.
            sleep(10000);
        }

        }



    public static void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

}

