package pt.tpsi.ad.pi4j.events;


@FunctionalInterface
public interface SimpleEventHandler {

    void handle();
}